================================================================================
NVIDIA RIVA TNT Display Driver for Windows 9x   version 4.10.01.xxxx, MM/DD/YYYY
================================================================================

Operating systems supported
---------------------------
Microsoft Windows 95
Microsoft Windows 98


Adapters supported
------------------
NVIDIA RIVA TNT


File list
---------
NV4AGP.INF   - Windows 9x display driver information file for RIVA TNT AGP
               adapters (not present in PCI driver package)
NV4CPL.DLL   - RIVA TNT display properties extension
NV4CPL.HLP   - RIVA TNT display properties extension help file
NV4DD32.DLL  - RIVA TNT DirectDraw driver
NV4DISP.INF  - Windows 9x display driver information file for RIVA TNT PCI
               adapters (not present in AGP driver package)
NV4DISP.DRV  - RIVA TNT display driver
NV4OGL.DLL   - RIVA TNT OpenGL driver
NV4QTWK.DLL  - RIVA TNT taskbar applet
NVARCH16.DLL - RIVA TNT interface layer to NV architecture for 16-bit clients
NVARCH32.DLL - RIVA TNT interface layer to NV architecture for 32-bit clients
NVCORE.VXD   - RIVA TNT Resource Manager kernel
NVMINI.VXD   - RIVA TNT mini-VDD for VGA virtualization and device Plug-N-Play
NVMINI2.VXD  - RIVA TNT mini-VDD for device Plug-N-Play of secondary devices
README.TXT   - The file you're reading.
VGARTD.VXD   - Windows 95 AGP support file (not present in PCI driver
               package)

Installation instructions
-------------------------
Windows 95
----------

To prepare for installation of the drivers

1 Start Microsoft Windows 95.

2 Click the Start button, point to Settings, and click Control Panel.

3 Double-click Display, and click the Settings tab.

4 Click Adapter, click the Change tab, click Next.

5 Select the option to display a list of drivers, then click Next.

6 Select Show all Hardware button, then select the Standard display types from the 
  Manufactures list.

7 Select Standard PCI Graphics Adapter (VGA) from the list, then select Next.

8 Click Next to install the driver, click Finish, then select Apply to complete 
  the installation.



To install the drivers

1 Click the Start button, point to Settings, and click Control Panel.

2 Double-click Display, and click the Settings tab.

3 Click Advanced Properties, click the Adaptor tab, then click Change.

4 Select Have Disk, then insert the NVIDIA RIVA TNT Driver Disk 1 into the 
  3.5" diskette drive, and select the drive letter of the diskette drive.

5 Select or type the path to the 3.5" floppy drive, then click OK.

  Windows should find files for the NVidia RIVA TNT.  If Windows cannot 
  find the files, check that the path name for the diskette is correct and 
  that the correct diskette is inserted in it. 

6 If Windows found the files, select OK.

  Windows copies the files to the hard disk.  

7 Insert the NVIDIA RIVA TNT Driver Disk 2, and click OK when Windows asks for the 
  NVIDIA RIVA TNT Driver Disk 2.  

8 Click Apply, click OK, then click Apply.

9 Remove diskettes from the diskette drive, then click Yes when Windows asks 
  if you wish to restart the computer.  




Windows 98
----------

To prepare for installation of the drivers

1 Start Microsoft Windows 98.

2 Click the Start button, point to Settings, and click Control Panel.

3 Double-click Display, and click the Settings tab.

4 Click Adapter, click the Change tab, click Next.

5 Select the option to display a list of drivers, then click Next.

6 Select Show all Hardware button, then select the Standard display types from the 
  Manufactures list.

7 Select Standard PCI Graphics Adapter (VGA) from the list, then select Next.

8 Click Next to install the driver, click Finish, then select Apply to complete 
  the installation.



To install the drivers

1 Click the Start button, point to Settings, and click Control Panel.

2 Double-click Display, and click the Settings tab.

3 Click Advanced Properties, click the Adaptor tab, then click Change.

4 Insert the NVIDIA RIVA TNT Driver Disk 1 into the 3.5" diskette drive.

5 Click Next, click Next, then Click Next.

5 Select or type the path to the 3.5" diskette driver, then click OK.

  Windows should find files for the NVidia RIVA TNT.  If Windows cannot 
  find the files, check that the path name for the diskette is correct and 
  that the correct diskette is inserted in it. 

6 If Windows found the files, click Next.

  Windows copies the files to the hard disk.  

7 Insert the NVIDIA RIVA TNT Driver Disk 2, and click OK when Windows asks for the 
  NVIDIA RIVA TNT Driver Disk 2.  

8 Click Finish to complete the installation.

9 Remove diskettes from the diskette drive, then click Yes when Windows asks 
  if you wish to restart the computer.  


Uninstall instructions
----------------------

To uninstall the drivers

1 Click the Start button, point to Settings, and click Control Panel.

2 Double-click Add/Remove Programs, select Control Freak, then click Add/Remove.



Control Freak 
-------------

To access Control Freak, Nvidia's Control Panel applet

1 Click the Start button, point to Settings, and click Control Panel.

2 Double-click Display, and click the RIVA tab.

3 Right click on each option to display information about each setting.


Tips for Users
--------------


Known Issues
------------


Revision history
----------------


================================================================================
Copyright 1999, NVIDIA Corporation.                         All rights reserved.
Document number: DR-00008-001
================================================================================

