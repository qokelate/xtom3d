Release 2.77 Release Notes

This driver is Release 2.77 of the NVIDIA Reference Driver. This release of the 
display driver is to be used with boards based on the RIVA128 and RIVA 128ZX 
chips. This release includes drivers for both WinNT4.0 and Win95/98 in either an 
AGP or PCI configuration. This Reference Driver is supplied to board 
manufacturers for their use in developing fully supported drivers customized for 
their specific board configuration. While we expect this driver to operate correctly 
on RIVA based boards, we are not able to provide full product support for other 
manufacturers products. It is recommended that end users install the drivers 
supplied from their board manufacturer to receive full product support.

This release includes support for DirectX 6.0 (DX6), multi-monitor configurations, 
and AMD CPUs with 3DNOW!.

If you were using a Win95 driver from a board manufacturer that also provided a 
Control Panel applet, (like Diamond�s InControl Tools, STB�s Vision, etc.) that 
applet will not work correctly with the NVIDIA Reference Driver and can cause 
system problems. It should be removed before these new drivers are installed. 
(See Installing from non-NVIDIA drivers, below.)

System Requirements to use the NVIDIA Reference Drivers

Win95 System requirements:
- OSR2 for full AGP functionality (which includes Microsoft's OPENGL32.DLL)
- Microsoft's OPENGL32.DLL
- Microsoft�s Dx5 or greater
- 2MB disk space

Win98 System requirements
- Microsoft�s Dx5 or greater
- 2MB disk space

WinNT System requirements:
- Service Pack 3 
- 2MB disk space

Downloading the NVIDIA Reference Drivers: 

To download the Release 2.77 Reference Drivers begin by clicking on the 
correct driver version for your system. 
select WIN9xPCI.ZIP to install drivers on Win95 PCI systems
select Win95AGP.ZIP to install drivers on Win95 AGP systems
select WIN98ALL.ZIP to install drivers on Win98 AGP or PCI systems
select NT40R128.ZIP to install drivers on WinNT systems.
This will download the compressed driver to your system. Save it in a temporary 
directory on your system disk.
	example: c:\RIVA128
The following sections will help you install our latest Win95/98 or WinNT display 
drivers which include the OpenGL ICD driver.

Win95 Installation Information: 

Before installing the new drivers it is recommended that you have a copy of your 
current drivers, usually supplied with your board. 

If not previously installed, you will need to install these on your system first:

1. OSR2 or later for AGP systems (usually pre-installed on AGP systems).  
2. Install Dx5 or greater. This is contained in your board vendors drivers, on the 
Microsoft web site, or on a recent DirectX application. It is recommended you 
install the latest Service Pack from Microsoft. You can obtain this by browsing for 
"Support Drivers, Patches and Service Packs" \ "Windows 95 Updates"  from:    
http://www.microsoft.com/msdownload/default.htm
3. If you have OSR2 or later installed on your system you should already have 
Microsoft�s OPENGL32.DLL installed on your system. If you do not already have 
a version of OPENGL32.DLL in your Windows\System, or you have another 
vendor specific OPENGL32.DLL file installed, you need to install Microsoft�s 
OPENGL32.DLL. You can obtain this file and other required files from:
ftp://ftp.microsoft.com/Softlib/MSLFILES/opengl95.exe

When you are ready: 
4. Unzip WIN95xxx.ZIP to an empty folder (such as C:\RIVA128).
5. Close all programs 
6. Install the driver using the Display Properties dialog box:
Click Start, then Settings, then Control Panel.
Start the "Display" applet program. 
Select the "Settings" tab
Push the "Change Display Type" button (or the �Advanced Properties� 
button).
Push the "Change" button in the "Adapter Type" area.
The "Select Device" dialog box will appear, push the �Have Disk� button.
Specify the path to the new unzipped driver by pressing �Browse��
After selecting the correct path press �OK�. 
Click �OK� twice to install the new drivers. Close down the open windows.
7. After successfully installing the reference drivers, you will need to restart the 
operating system for the new drivers to take effect.

Windows 98 Installation Information
1.Unzip WIN9xxxx.ZIP to an empty folder (such as C:\RIVA128).
2. Close all programs 
3. Install the driver using the Display Properties dialog box:
Click Start, then Settings, then Control Panel.
Start the "Display" applet program. 
Select the "Settings" tab.
Push the "Advanced Properties� button.
Select the �Adapter� tab.
Push the �Change� button.
Push the �Next� button.
Select the radio button labeled �Display a list of all the drivers in a specific 
location�� 
Push the �Have Disk� button and specify the location where you unzipped 
the files.  The system should find a .inf file in the location you specify.  
Press �OK�. 
Click �OK�, then �Next�, then �Finish�
7. After successfully installing the reference drivers, you will need to restart the 
operating system for the new drivers to take effect.


WinNT Installation Information:

Before installing the new drivers it is recommended that you have a copy of your 
current drivers, usually supplied with your board. 

If not previously installed, you will need to install this on your system first:

1. Install Microsoft's Service Pack 3 for Windows NT 4.0 on your system. You 
can obtain this by browsing for "Support Drivers, Patches and Service Packs" \ 
"Windows NT Service Packs" from:    
 http://www.microsoft.com/msdownload/default.htm
	
When you are ready: 
2. Unzip NT.ZIP to an empty folder. 
3. Close all programs
4. Choose NT's Start\Settings\Control Panel\Display\Settings\Display 
Type\Change\Have Disk\Browse.
5. Locate the folder with the unzipped reference drivers...Display should list 
NVidia RIVA 128
6. After NT successfully installs the reference drivers, you will need to restart the 
operating system for the new drivers to take effect.

Installing from non-NVIDIA drivers:

If you are installing the NVIDIA Reference Drivers and presently have non-
NVIDIA supplied drivers installed, it is recommended that you uninstall your 
existing driver�s Control Panel tools before installing the NVIDIA Reference 
Drivers. Our driver does not include the hooks in it to support the tools provided 
by other board manufacturers. As a result, their tools will not operate correctly 
with the NVIDIA Reference Drivers and could cause system problems if you try 
to use them with our drivers. The best way to uninstall drivers is to use an 
uninstall utility provided by your board manufacturer. Please contact them for 
information on how to uninstall their tools. 

Uninstalling NVIDIA drivers:

If you have a need to do this, first start by uninstalling Control Freak. To do this 
use the Add/Remove Programs dialog box:
Click Start, then Settings, then Control Panel.
Start the "Add/Remove Programs" applet program. 
Select Control Freak, and click �Add/Remove�.
You will now be able to re-install your original driver on the system.

General information for all users.

About OpenGL:
The NVIDIA Reference Driver Release 2.77 includes our latest version of the 
OpenGL ICD for RIVA 128 and RIVA 128ZX. This OpenGL ICD is now available 
for both Windows 95 and Windows NT.  It accelerates rendering of OpenGL 
applications when:
  - Display is set to 16-bits per pixel
  - Enough video memory exists to support the OpenGL resolution requested
  - Microsoft's OPENGL32.DLL is correctly installed

Several pre-release versions of the OpenGL ICD have previously been made 
available through the Internet. This version should be much more stable, and 
should perform better in almost all cases.

Microsoft's OpenGL will auto-detect that the RIVA products have hardware-
accelerated OpenGL available, and use that whenever possible.  If OpenGL 
applications complain about missing  required DLL's, or if you are seeing 
unusual OpenGL behavior, then it is likely that either you are missing 
OPENGL32.DLL, or that an application shipped with a version of 
OPENGL32.DLL that is not compatible with the RIVA OpenGL ICD.  You should 
look in the application's directory for a file called OPENGL32.DLL, and rename it. 
The application will then use the OPENGL32.DLL from the Windows\System or 
WinNT\System32 directory. You also can obtain the correct OPENGL32.DLL is 
by re-installing it from the WindowsNT CD.

About Control Freak:

Also included in the NVIDIA Reference Drivers is our Control Panel applet, 
Control Freak. This applet adds a RIVA tab to the Display Properties Dialog box. 
There are several useful controls and setting information here. To learn what 
each setting can do, just right click on the setting to get an information box.

Additional information:

The files included with the Release 2.77 Reference Drivers:

PCI files
NV3.VXD
NV3API.DLL 
NV3DD32.DLL
NV3DISP.DRV
NV3DISP.INF
NV3MINI2.VXD 
NV3OGL.DLL
NV3QTWK.DLL
NV3RM.VXD
NV3SYS.DLL
NV3TWEAK.DLL
NV3TWEAK.HLP
NV3TWEAK.INF

AGP files:
NV3.VXD	
NV3AGP.INF	
NV3API.DLL	
NV3DD32.DLL
NV3DISP.DRV	
NV3MINI2.VXD
NV3OGL.DLL
NV3QTWK.DLL	
NV3RM.VXD	
NV3SYS.DLL
NV3TWEAK.DLL	
NV3TWEAK.HLP	
NV3TWEAK.INF	
VGARTD.VXD	

NT 4.0 files:
NV3OGLNT.DLL
NV_DISP.DLL
NV_MINI.SYS
NV_DISP.INF

Modes supported in Release 2.77

These are the Win95 and WinNT modes now supported by the drivers in 
Release 2.77:

Resolution	BitDepth	RefreshRates

320x200		8,16,32	  	70,72,75,85,100,120		(DDraw only)
320x240		8,16,32	  	60,70,72,75,85,100,120		(DDraw only)
400x300		8,16,32	  	60,70,72,75,85,100,120		(DDraw only)
480x360		8,16,32	  	60,70,72,75,85,100,120		(DDraw only)
512x384		8,16,32	  	60,70,72,75,85,100,120		(DDraw only)
640x400		8,16,32	  	70,72,75,85,100,120		(DDraw only)
640x480		8,16,32		60,70,72,75,85,100,120		
800x600		8,16,32		60,70,72,75,85,100,120		
960x720		8,16,32		60,70,72,75,85,100,120		(DDraw only)
1024x768	8,16,32		60,70,72,75,85,100,120		
1152x864	8,16,32		60,70,72,75,85,100,120		
1280x1024	8,16,32*	60,70,72,75,85,100,120		
1600x1200	8,16,32*	60,70,72,75,85	
1920x1080	8,16*		60,70,72,75,85	
1920x1200	8,16*		60,70,72,75
1880x1440	8,16*		60

* requires an 8meg framebuffer

